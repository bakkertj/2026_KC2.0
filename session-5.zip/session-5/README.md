# Session 5 materials

- slides/: the deck as PDF
- demos/: the source of every code example on the slides; each file's header has a Compiler
  Explorer link, and handouts/compiler-explorer-links.pdf lists them all (GCC 14, -std=c++23)
- exercise/: the in-class exercise (README.md, starter/, tests/, data/)
- handouts/: cheat sheets, the feature timeline, the toolchain support matrix, the adoption
  roadmap worksheet, and the Compiler Explorer links index, as PDF and DOCX

The demos and the exercise build with the course repository's CMake setup
(GCC 14 or Clang 18, CMake 3.28+); the demos also run as-is on Compiler Explorer.
